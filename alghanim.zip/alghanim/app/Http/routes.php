<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/','ReportController@index')->name('dashboard');
Route::post('/home','ReportController@index')->name('dashboard');

Route::get('/dashboard','ReportController@index')->name('dashboard');
Route::post('/dashboard','ReportController@index')->name('dashboard');
Route::post('/getquestion','ReportController@getquestion');

Route::get('/customer','ReportController@customer_new');
Route::get('/customer/{mobile}','ReportController@customer');
Route::post('/customer/store','ReportController@store');
Route::post('/enquiry/store','ReportController@enqstore');
Route::post('/customervehicle/store','ReportController@vehstore');
Route::get('/customer/{mobile}/{user}','ReportController@customeruser');
Route::get('/customer_old/{mobile}/{user}','ReportController@customerold');
Route::get('/customer/{mobile}/{user}/{cusid}','ReportController@customeruser');

//AjaxController
Route::post('/getcategory','AjaxController@getcategory');
Route::post('/customerinfo','AjaxController@customerinfo');
Route::post('/vehicleinfo','AjaxController@vehicleinfo');


Route::get('/vehicle','VehicleController@index')->name('vehicle-list');
Route::get('/vehicle/create','VehicleController@create')->name('vehicle-new');
Route::get('/vehicle/{id}','VehicleController@show')->name('vehicle-list');
Route::post('/vehicle/store','VehicleController@store');
Route::post('/vehicle/description','VehicleController@description');
Route::get('/vehicle/{id}/edit','VehicleController@edit')->name('vehicle-list');
Route::post('/vehicle/{id}/update','VehicleController@update');


Route::get('/upscale','UpscaleController@index')->name('upscale-list');
Route::get('/upscale/create','UpscaleController@create')->name('upscale-new');
Route::get('/upscale/{id}','UpscaleController@show')->name('upscale-list');
Route::post('/upscale/store','UpscaleController@store');
Route::get('/upscale/{id}/edit','UpscaleController@edit')->name('upscale-list');
Route::post('/upscale/{id}/update','UpscaleController@update');


Route::get('/report/outbound','CallLogsReportController@index')->name('outbound-report');
Route::post('/report/outbound','CallLogsReportController@index')->name('outbound-report');
Route::get('/report/inbound','CallLogsReportController@inbound')->name('inbound-report');
Route::post('/report/inbound','CallLogsReportController@inbound')->name('inbound-report');
Route::get('/report/missed','CallLogsReportController@missed')->name('missed-report');
Route::post('/report/missed','CallLogsReportController@missed')->name('missed-report');


Route::get('/report/agent/time','AgentReportController@index')->name('agent-time');
Route::post('/report/agent/time','AgentReportController@index')->name('agent-time');

Route::get('/report/agent/performance','AgentReportController@performance')->name('agent-performance');
Route::post('/report/agent/performance','AgentReportController@performance')->name('agent-performance');

Route::get('/report/agent/status','AgentReportController@status')->name('agent-status');
Route::post('/report/agent/status','AgentReportController@status')->name('agent-status');

Route::get('/report/team/performance','AgentReportController@team')->name('team-performance');
Route::post('/report/team/performance','AgentReportController@team')->name('team-performance');


Route::get('/report/call_log','CallLogsReportController@call_log')->name('call-log');
Route::post('/report/call_log','CallLogsReportController@call_log')->name('call-log');

Route::get('/leads/list','ListManagementReportController@index')->name('lead-list');
Route::post('/leads/list','ListManagementReportController@index')->name('lead-list');
Route::get('/leads/list/{userid}','ListManagementReportController@resetid')->name('lead-list');


Route::get('/inquiries','ReportController@inquiries')->name('inquiries');
Route::post('/inquiries','ReportController@inquiries')->name('inquiries');
Route::get('/appointments/{id}','ReportController@vappointments')->name('appointments');
Route::get('/useranswers','ReportController@useranswers')->name('user-answer');
Route::post('/useranswers','ReportController@useranswers')->name('user-answer');
Route::get('/useranswers/{id}','ReportController@vuseranswers')->name('user-answer');
Route::get('/appointments','ReportController@appointments')->name('appointments');
Route::post('/appointments','ReportController@appointments')->name('appointments');


Route::get('/auto-dial','ReportController@auto_dial')->name('auto-dial');
Route::post('/auto/upload','ReportController@upload');
Route::get('/autoupload-dial','ReportController@auto_upload')->name('auto-upload');
Route::post('/autoupload/upload','ReportController@autodial_upload');
Route::post('/autoupload/folder','ReportController@autodial_folder');

Route::get('/record/outbound','RecordingController@index')->name('outbound-record');
Route::post('/record/outbound','RecordingController@index')->name('outbound-record');
Route::get('/record/inbound','RecordingController@inbound')->name('inbound-record');
Route::post('/record/inbound','RecordingController@inbound')->name('inbound-record');
