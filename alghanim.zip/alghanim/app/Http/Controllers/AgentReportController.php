<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Excel;
use App\VicidialUsers;
use App\VicidialUserGroup;
use App\VicidialCloserLog;
use App\VicidialCampaign;
use App\VicidialCampaignStat;
use App\VicidialAgentLive;
use App\VicidialAgentLog; 
use App\VicidialDialLog;
use App\VicidialHopper;
use App\Average;

class AgentReportController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
    //print_r('expression');   exit();   
        $fromdate = date("Y-m-d");
        $todate = date("Y-m-d");
        $usergroup = '';
        $campaign = '';

        if(!empty($request->fromdate)){
            $fromdate = $request->fromdate;
            $parts = explode('-',$fromdate);
            $fromdate = $parts[2] . '-' . $parts[0] . '-' . $parts[1];
        }
        if(!empty($request->todate)){
            $todate = $request->todate;
            $parts = explode('-',$todate);
            $todate = $parts[2] . '-' . $parts[0] . '-' . $parts[1];
        }

        $todate1 = date('Y-m-d', strtotime("+1 day", strtotime($todate)));

        $campaigns = VicidialCampaign::select('campaign_id','campaign_name')->where('active','Y')->get();
        $usergroups = VicidialUserGroup::all();


        $vicidial_agent_log = VicidialAgentLog::join('vicidial_users', 'vicidial_agent_log.user', '=', 'vicidial_users.user')->whereBetween('event_time',[$fromdate, $todate1])->where('talk_sec','<','65000')->where('pause_sec','<','65000')->where('wait_sec','<','65000')->where('dispo_sec','<','65000');

        $all_sec = VicidialAgentLog::whereBetween('event_time',[$fromdate, $todate1]);

        $closer_log = $vicidial_agent_log->select('vicidial_agent_log.user', DB::raw('count(*) as calls'))->addSelect('vicidial_users.full_name','vicidial_agent_log.user_group')->groupBy('vicidial_agent_log.user','vicidial_agent_log.user_group','vicidial_users.full_name')->get();
        
        if(!empty($request->usergroup)){
            $usergroup = $request->usergroup;
            $vicidial_agent_log = $vicidial_agent_log->where('user_group',$usergroup);
            $all_sec = $all_sec->where('user_group',$usergroup);
        }

        if(!empty($request->campaign)){
            $campaign = $request->campaign;
            $vicidial_agent_log = $vicidial_agent_log->where('campaign_id',strtoupper($campaign));
            $all_sec = $all_sec->where('campaign_id',strtoupper($campaign));
        }

        $all_sec = $all_sec->get();


        $users = VicidialUsers::select('full_name','user')->get();

      
        //print_r($usergroup); exit();  
        return view('reports.agent_time',compact('closer_log','all_sec','users','campaigns','usergroups','fromdate','todate','campaign','usergroup'));
    }


    public function performance(Request $request)
    {       
    //print_r('expression');   exit();   
        $fromdate = date("Y-m-d");
        $todate = date("Y-m-d");
        $usergroup = '';
        $campaign = '';

        if(!empty($request->fromdate)){
            $fromdate = $request->fromdate;
            $parts = explode('-',$fromdate);
            $fromdate = $parts[2] . '-' . $parts[0] . '-' . $parts[1];
        }
        if(!empty($request->todate)){
            $todate = $request->todate;
            $parts = explode('-',$todate);
            $todate = $parts[2] . '-' . $parts[0] . '-' . $parts[1];
        }

        $todate1 = date('Y-m-d', strtotime("+1 day", strtotime($todate)));

        $campaigns = VicidialCampaign::where('active','Y')->get();
        $usergroups = VicidialUserGroup::all();


        $vicidial_agent_log = VicidialAgentLog::join('vicidial_users', 'vicidial_agent_log.user', '=', 'vicidial_users.user')->whereBetween('event_time',[$fromdate, $todate1])->where('talk_sec','<','65000')->where('pause_sec','<','65000')->where('wait_sec','<','65000')->where('dispo_sec','<','65000');

        $all_sec = VicidialAgentLog::whereBetween('event_time',[$fromdate, $todate1]);

        $closer_log = $vicidial_agent_log->select('vicidial_agent_log.user', DB::raw('count(*) as calls'))->addSelect('vicidial_users.full_name','vicidial_agent_log.user_group')->groupBy('vicidial_agent_log.user','vicidial_agent_log.user_group','vicidial_users.full_name')->get();
        //print_r($closer_log);   exit();  

        if(!empty($request->usergroup)){
            $usergroup = $request->usergroup;
            $vicidial_agent_log = $vicidial_agent_log->where('user_group',$usergroup);
            $all_sec = $all_sec->where('user_group',$usergroup);
        }

        if(!empty($request->campaign)){
            $campaign = $request->campaign;
            $vicidial_agent_log = $vicidial_agent_log->where('campaign_id',strtoupper($campaign));
            $all_sec = $all_sec->where('campaign_id',strtoupper($campaign));
        }

        $all_sec = $all_sec->get();


        $users = VicidialUsers::select('full_name','user')->get();
      
        //print_r($usergroup); exit();  
        return view('reports.agent',compact('closer_log','all_sec','users','campaigns','usergroups','fromdate','todate','campaign','usergroup'));
    }


    public function status(Request $request)
    {
    //print_r('expression');   exit();  
        $fromdate = date("Y-m-d");
        $todate = date("Y-m-d");
        $usergroup = '';
        $campaign = '';

        if(!empty($request->fromdate)){
            $fromdate = $request->fromdate;
            $parts = explode('-',$fromdate);
            $fromdate = $parts[2] . '-' . $parts[0] . '-' . $parts[1];
        }
        if(!empty($request->todate)){
            $todate = $request->todate;
            $parts = explode('-',$todate);
            $todate = $parts[2] . '-' . $parts[0] . '-' . $parts[1];
        }

        $todate1 = date('Y-m-d', strtotime("+1 day", strtotime($todate)));

        $campaigns = VicidialCampaign::where('active','Y')->get();
        $usergroups = VicidialUserGroup::all();


        $vicidial_agent_log = VicidialAgentLog::join('vicidial_users', 'vicidial_agent_log.user', '=', 'vicidial_users.user')->whereBetween('event_time',[$fromdate, $todate1])->where('talk_sec','<','65000')->where('pause_sec','<','65000')->where('wait_sec','<','65000')->where('dispo_sec','<','65000');

        $all_sec = VicidialAgentLog::whereBetween('event_time',[$fromdate, $todate1]);

        $closer_log = $vicidial_agent_log->select('vicidial_agent_log.user', DB::raw('count(*) as calls'))->addSelect('vicidial_users.full_name','vicidial_agent_log.user_group')->groupBy('vicidial_agent_log.user','vicidial_agent_log.user_group','vicidial_users.full_name')->get();
        //print_r($closer_log);   exit();  

        if(!empty($request->usergroup)){
            $usergroup = $request->usergroup;
            $vicidial_agent_log = $vicidial_agent_log->where('user_group',$usergroup);
            $all_sec = $all_sec->where('user_group',$usergroup);
        }

        if(!empty($request->campaign)){
            $campaign = $request->campaign;
            $vicidial_agent_log = $vicidial_agent_log->where('campaign_id',strtoupper($campaign));
            $all_sec = $all_sec->where('campaign_id',strtoupper($campaign));
        }

        $all_sec = $all_sec->get();


        $users = VicidialUsers::select('full_name','user')->get();
      
        //print_r($usergroup); exit();  
        return view('reports.agent_status',compact('closer_log','all_sec','users','campaigns','usergroups','fromdate','todate','campaign','usergroup'));
    }

    public function team(Request $request)
    {
    //print_r('expression');   exit();   
        $fromdate = date("Y-m-d");
        $todate = date("Y-m-d");
        $usergroup = '';
        $campaign = '';

        if(!empty($request->fromdate)){
            $fromdate = $request->fromdate;
            $parts = explode('-',$fromdate);
            $fromdate = $parts[2] . '-' . $parts[0] . '-' . $parts[1];
        }
        if(!empty($request->todate)){
            $todate = $request->todate;
            $parts = explode('-',$todate);
            $todate = $parts[2] . '-' . $parts[0] . '-' . $parts[1];
        }

        $todate1 = date('Y-m-d', strtotime("+1 day", strtotime($todate)));

        $campaigns = VicidialCampaign::where('active','Y')->get();
        $usergroups = VicidialUserGroup::all();


        $vicidial_agent_log = VicidialAgentLog::join('vicidial_users', 'vicidial_agent_log.user', '=', 'vicidial_users.user')->whereBetween('event_time',[$fromdate, $todate1])->where('talk_sec','<','65000')->where('pause_sec','<','65000')->where('wait_sec','<','65000')->where('dispo_sec','<','65000');

        $all_sec = VicidialAgentLog::whereBetween('event_time',[$fromdate, $todate1]);

        $closer_log = $vicidial_agent_log->select('vicidial_agent_log.user', DB::raw('count(*) as calls'))->addSelect('vicidial_users.full_name','vicidial_agent_log.user_group')->groupBy('vicidial_agent_log.user','vicidial_agent_log.user_group','vicidial_users.full_name')->get();
        //print_r($closer_log);   exit();  

        if(!empty($request->usergroup)){
            $usergroup = $request->usergroup;
            $vicidial_agent_log = $vicidial_agent_log->where('user_group',$usergroup);
            $all_sec = $all_sec->where('user_group',$usergroup);
        }

        if(!empty($request->campaign)){
            $campaign = $request->campaign;
            $vicidial_agent_log = $vicidial_agent_log->where('campaign_id',strtoupper($campaign));
            $all_sec = $all_sec->where('campaign_id',strtoupper($campaign));
        }

        $all_sec = $all_sec->get();


        $users = VicidialUsers::select('full_name','user')->get();
      
        //print_r($usergroup); exit();  
        return view('reports.team',compact('closer_log','all_sec','users','campaigns','usergroups','fromdate','todate','campaign','usergroup'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
