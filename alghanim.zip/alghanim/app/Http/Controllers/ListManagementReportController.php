<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\VicidialList;
use App\VicidialLists;

class ListManagementReportController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        //print_r($request->all()); exit();
        $list_id = '';
        $status = '';
        $list_ids = VicidialLists::get();
        $statuses = VicidialList::select(DB::raw('count(*) as status_count, status'))->groupBy('status')->get();
        if(!empty($request->list_id) && !empty($request->status)){

            $status = implode(",", $request->status);
            $list_id = intval($request->list_id);

            if($request->resetstatus == '1'){
            //print_r("reset0"); exit();
            VicidialList::whereIn('status',explode(",", $status))->where('list_id',$list_id)->update(['status'=>'NEW','called_since_last_reset'=>'N']);
            }
            if($request->clearstatus == '1'){
            //print_r("reset0"); exit();
            VicidialList::whereIn('status',explode(",", $status))->where('list_id',$list_id)->delete();
            }

            $dial_lists = VicidialList::where('list_id',$list_id)->whereIn('status',explode(",", $status))->paginate(100);
            $dial_lists_count = VicidialList::where('list_id',$list_id)->whereIn('status',explode(",", $status))->count();

        }
        elseif(!empty($request->list_id) && empty($request->status)){
            
            $list_id = intval($request->list_id);

            if($request->resetstatus == '1'){
            //print_r("reset1"); exit();
            VicidialList::where('list_id',$list_id)->update(['status'=>'NEW','called_since_last_reset'=>'N']);
            }
            
            if($request->clearstatus == '1'){
            //print_r("reset1"); exit();
            VicidialList::where('list_id',$list_id)->delete();
            }

            $dial_lists = VicidialList::where('list_id',$list_id)->paginate(100);
            $dial_lists_count = VicidialList::where('list_id',$list_id)->count();
        
        }
        elseif(empty($request->list_id) && !empty($request->status)){
            $status = implode(",", $request->status);

            if($request->resetstatus == '1'){
            //print_r("reset2"); exit();
            VicidialList::whereIn('status',explode(",", $status))->update(['called_since_last_reset'=>'N','status'=>'NEW']);
            }
            if($request->clearstatus == '1'){
            //print_r("reset2"); exit();
            VicidialList::whereIn('status',explode(",", $status))->delete();
            }
            $dial_lists = VicidialList::whereIn('status',explode(",", $status))->paginate(100);
            $dial_lists_count = VicidialList::whereIn('status',explode(",", $status))->count();
        
        
        }
        else{

            if($request->resetstatus == '1'){
            //print_r("reset3"); exit();
            VicidialList::update(['status'=>'NEW','called_since_last_reset'=>'N']);
            }
            if($request->clearstatus == '1'){
            //print_r("reset2"); exit();
            VicidialList::delete();
            }
            
            $dial_lists = VicidialList::paginate(100);   
            $dial_lists_count = VicidialList::count();   
        
        
              
        }
        //print_r($statuses); exit();
        return view('list.index',compact('dial_lists','fromdate','todate','phone','user','status','list_id','dial_lists_count','list_ids','statuses'));
    }

    public function resetid($userids)
    {
        $lead_ids = explode(",", $userids);
        foreach ($lead_ids as $lead) {
        VicidialList::where('list_id',$lead)->update(['status'=>'NEW','called_since_last_reset'=>'N']);
        }
        return redirect('/leads/list');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
