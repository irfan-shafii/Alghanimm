<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class VehicleController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $vehicles = DB::table('vehicles')->get();
        return view('vehicle.index',compact('vehicles'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $accounts = DB::table('account')->where('mobile_number','86088444')->get();
        return view('vehicle.create',compact('accounts'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //print_r($request->all()); exit();
        DB::table('vehicles')->insert(['phone_number'=>$request->mobile,'vehicle_type'=>$request->type,'vehicle_brand'=>$request->brand,'vehicle_model'=>$request->model,'vehicle_plate_no'=>$request->plateno,'vehicle_chasis_no'=>$request->chasisno,'vehicle_model_year'=>$request->modelyear,'vehicle_date_of_sale'=>$request->dosale,'dealer'=>$request->dealer,'town'=>$request->town,'vehicle_warranty_years'=>$request->warranty,'vehicle_status'=>$request->status]);

        return redirect('/vehicle');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        
        $vehicle_descriptions = DB::table('vehicle_descriptions')->where('vehicle_id',$id)->orderBy('id','desc')->get();
        $vehicle = DB::table('vehicles')->where('id',$id)->get();
        return view('vehicle.show',compact('vehicle','vehicle_descriptions'));
    }

    public function description(Request $request)
    {
        //print_r($request->all()); exit();
        DB::table('vehicle_descriptions')->insert(['mobile_number'=>$request->mobile,'vehicle_wip_no'=>$request->wipnumber,'vehicle_description'=>$request->description,'vehicle_id'=>$request->vehicleid]);

        return redirect('/vehicle');
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $vehicle_descriptions = DB::table('vehicle_descriptions')->where('vehicle_id',$id)->orderBy('id','desc')->get();
        $vehicle = DB::table('vehicles')->where('id',$id)->get();
        return view('vehicle.edit',compact('vehicle','vehicle_descriptions'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //print_r($request->all()); exit();
        DB::table('vehicles')->where('id',$request->vehicleid)->update(['phone_number'=>$request->mobile,'vehicle_type'=>$request->type,'vehicle_brand'=>$request->brand,'vehicle_model'=>$request->model,'vehicle_plate_no'=>$request->plateno,'vehicle_chasis_no'=>$request->chasisno,'vehicle_model_year'=>$request->modelyear,'vehicle_date_of_sale'=>$request->dosale,'dealer'=>$request->dealer,'town'=>$request->town,'vehicle_warranty_years'=>$request->warranty,'vehicle_status'=>$request->status]);
        if(!empty($request->wipnumber)){
        DB::table('vehicle_descriptions')->insert(['mobile_number'=>$request->mobile,'vehicle_wip_no'=>$request->wipnumber,'vehicle_description'=>$request->description,'vehicle_id'=>$request->vehicleid]);
        }

        return redirect('/vehicle');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
