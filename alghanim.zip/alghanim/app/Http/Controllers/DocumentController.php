<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class DocumentController extends Controller
{
   

    public function history($docref=0)
    { 

        $soapUrl = "http://172.16.4.16:790/AlghanimAutoline/WCOM?wsdl";
        //print_r($soapUrl); exit();
        //$soapUser = "username";  //  username
        //$soapPassword = "password"; // password

        // xml post structure
        $xml_post_string = '<?xml version="1.0" encoding="UTF-8"?>
        <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:dcom="http://172.16.4.16:790/AlghanimAutoline/WCOM">
        <soapenv:Body>
        <dcom:GetArchivedDocument>
        <dcom:Identification>
        <dcom:SessionId>10000005</dcom:SessionId>
        </dcom:Identification>
        <dcom:LookupCodes>
        <dcom:RooftopId>TABYAAS01</dcom:RooftopId>
        <dcom:DocRef>'.$docref.'</dcom:DocRef>
        <dcom:Terminal>1021</dcom:Terminal>
        </dcom:LookupCodes>
        </dcom:GetArchivedDocument>
        </soapenv:Body>
        </soapenv:Envelope>';

        $headers = array(
        "Content-type: text/xml;charset=\"utf-8\"",
        "Accept: text/xml",
        "Cache-Control: no-cache",
        "Pragma: no-cache",
        "SOAPAction: urn:kcml-WCOM#GetArchivedDocument", 
        "Content-length: ".strlen($xml_post_string),
        ); //SOAPAction: your op URL

        $url = $soapUrl;

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $xml_post_string);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        // converting
        $response = curl_exec($ch); 
        //$info = curl_getinfo($response);
        //echo var_dump($response);
        curl_close($ch);

        // converting
        $response1 = str_replace("<soap:Body>","",$response);
        $response2 = str_replace("</soap:Body>","",$response1);

        // convertingc to XML
        $parser = simplexml_load_string($response2);
        $txtfile = $response;
        $myfilename ="";
        $urls = explode("http://", $txtfile);
        foreach ($urls as $url) {
            if (strpos($url, '.txt') !== false) {
                $fileext = explode(".txt", $url);
                $myfilename ='http://'.$fileext[0].'.txt';
            }
        }
        return redirect($myfilename);

    }
}
