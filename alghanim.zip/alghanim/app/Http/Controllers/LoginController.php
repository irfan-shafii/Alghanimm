<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Session;
use App\User;
use DB;
use App\VicidialUserGroup;
use App\VicidialCampaign;
use App\VicidialIngroup;

class LoginController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
    if(empty(Session::get('userid'))){ return redirect('/login'); }
        
        $users = DB::table('alghanim_users')->where('user_type','agent')->orderBy('id_user','desc')->paginate(100);
        return view('users.index',compact('users'));
    }

    public function customer()
    {
    if(empty(Session::get('userid'))){ return redirect('/login'); }
        $campaignids = Session::get('campaignid');
        
        $users = DB::table('account');
        if(!empty($campaignids)){
            $users = $users->whereIn('campaign_id',explode(",", $campaignids));
        }
        $users = $users->orderBy('id_account','desc')->paginate(100);
        return view('users.customer',compact('users'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function campaign()
    {
    if(empty(Session::get('userid'))){ return redirect('/login'); }
        $campaigns = VicidialCampaign::select('campaign_id','campaign_name')->where('active','Y')->get();
        $ingroups = VicidialIngroup::select('group_id','group_name')->get();
        $user_campaigns = DB::table('user_campaigns')->orderBy('id','asc')->get();
        return view('users.campaign',compact('campaigns','ingroups','user_campaigns'));
    }

    public function create()
    {
    if(empty(Session::get('userid'))){ return redirect('/login'); }
        $campaigns = VicidialCampaign::select('campaign_id','campaign_name')->where('active','Y')->get();
        $usergroups = VicidialUserGroup::select('user_group','group_name')->get();
        return view('users.create',compact('campaigns','usergroups'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function campaignstore(Request $request)
    {
        $campaignid = '';
        $ingroups = '';
        if (count($request->groups) > 0) {
        $ingroups = implode(",", $request->groups);
        }

        $checkid =  DB::table('user_campaigns')->where('campaigns',$request->campaigns)->get();
        if(count($checkid) > 0){
            DB::table('user_campaigns')->where('campaigns',$request->campaigns)->update(['campaigns'=>$request->campaigns,'ingroups'=>$ingroups]);
        }      
        else{            
            DB::table('user_campaigns')->insert(['campaigns'=>$request->campaigns,'ingroups'=>$ingroups]);
        }     
        return redirect('/users/campaigns');

    }

    public function userstore(Request $request)
    {
        $campaignid = '';
        $usergroups = '';
        if (count($request->campaigns) > 0) {
        $campaignid = implode(",", $request->campaigns);
        }
        if (count($request->groups) > 0) {
        $usergroups = implode(",", $request->groups);
        }
        DB::table('alghanim_users')->insert(['name'=>$request->name,'email'=>$request->email,'user_type'=>$request->user_type,'password'=>md5($request->password),'campaignid'=>$campaignid,'usergroups'=>$usergroups]);           
        return redirect('/users');

    }



    public function store(Request $request)
    {
        //print_r(md5($request->password)); exit(); 
        $user = DB::table('alghanim_users')->where('email',$request->email)->where('password',md5($request->password))->get();
        
        if(count($user) > 0){              
            Session::put('userid',$user[0]->id_user);
            Session::put('username',$user[0]->name);
            Session::put('useremail',$user[0]->email);
            Session::put('usertype',$user[0]->user_type);              
            Session::put('campaignid',$user[0]->campaignid);              
            Session::put('usergroups',$user[0]->usergroups);              
            return redirect('/');
        }
        else{

            return redirect('/login')->with('alert','invalid');
        }
    }


    public function logout()
    {       
            Session::put('userid','');
            Session::put('username','');
            Session::put('useremail','');
            Session::put('usertype','');         
            Session::put('campaignid','');      
            Session::put('usergroups','');    
            return redirect('/');
        
    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $user = User::where('id',$id)->get();
        $email = $user[0]->email;
        $name = $user[0]->name;
        return view('password',compact('id','name','email'))->with('alert','invalid');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $user = DB::table('alghanim_users')->where('id_user',$id)->first();
        $campaigns = VicidialCampaign::select('campaign_id','campaign_name')->where('active','Y')->get();
        $usergroups = VicidialUserGroup::select('user_group','group_name')->get();
        return view('users.edit',compact('user','campaigns','usergroups'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //print_r(md5($request->password)); exit(); 
        $campaignid = '';
        $usergroups = '';
        if (count($request->campaigns) > 0) {
        $campaignid = implode(",", $request->campaigns);
        }
        if (count($request->groups) > 0) {
        $usergroups = implode(",", $request->groups);
        }

    	if(!empty($request->password)){
    		$password = md5($request->password);
    	}
    	else{   		
    		$password = $request->cpassword;
    	}
        //print_r($campaignid); exit(); 
        DB::table('alghanim_users')->where('id_user',$id)->update(['name'=>$request->name,'email'=>$request->email,'password'=>$password,'campaignid'=>$campaignid,'usergroups'=>$usergroups]);           
        return redirect('/users');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
