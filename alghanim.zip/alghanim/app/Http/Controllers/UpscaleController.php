<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class UpscaleController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $vehicle_upscales = DB::table('vehicle_upscales')->get();
        return view('upscale.index',compact('vehicle_upscales'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('upscale.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //print_r($request->all()); exit();
        DB::table('vehicle_upscales')->insert(['topic'=>$request->topic,'brand'=>$request->brand,'model'=>$request->model,'description'=>$request->description]);

        return redirect('/upscale');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $upscale = DB::table('vehicle_upscales')->where('id',$id)->get();
        return view('upscale.edit',compact('upscale'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //print_r($request->all()); exit();
        DB::table('vehicle_upscales')->where('id',$id)->update(['topic'=>$request->topic,'brand'=>$request->brand,'model'=>$request->model,'description'=>$request->description]);

        return redirect('/upscale');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
