<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Session;
use App\VicidialCampaign;

class UpscaleController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
    if(empty(Session::get('userid'))){ return redirect('/login'); }

        $vehicle_upscales = DB::table('vehicle_upscales');
        $campaignids = Session::get('campaignid');

        if(!empty($campaignids)){
            $vehicle_upscales = $vehicle_upscales->whereIn('campaign_id',explode(",", $campaignids));
        }
        $vehicle_upscales = $vehicle_upscales->get();
        return view('upscale.index',compact('vehicle_upscales'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
    if(empty(Session::get('userid'))){ return redirect('/login'); }
        $campaignids = Session::get('campaignid');

        $campaigns = VicidialCampaign::select('campaign_id','campaign_name')->where('active','Y');

        if(!empty($campaignids)){
            $campaigns = $campaigns->whereIn('campaign_id',explode(",", $campaignids));
        }
        $campaigns = $campaigns->get();
        return view('upscale.create',compact('campaigns'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //print_r($request->all()); exit();
        if(!empty($request->campaigns)){
            $campaigns = implode(",", $request->campaigns);
        }
        DB::table('vehicle_upscales')->insert(['topic'=>$request->topic,'brand'=>$request->brand,'model'=>$request->model,'campaign_id'=>$campaigns,'description'=>$request->description]);

        return redirect('/upscale');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
    if(empty(Session::get('userid'))){ return redirect('/login'); }
        $campaignids = Session::get('campaignid');

        $campaigns = VicidialCampaign::select('campaign_id','campaign_name')->where('active','Y');

        if(!empty($campaignids)){
            $campaigns = $campaigns->whereIn('campaign_id',explode(",", $campaignids));
        }
        $campaigns = $campaigns->get();

        $upscale = DB::table('vehicle_upscales')->where('id',$id)->get();
        return view('upscale.edit',compact('upscale','campaigns'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //print_r($request->all()); exit();
        if(!empty($request->campaigns)){
            $campaigns = implode(",", $request->campaigns);
        }
        DB::table('vehicle_upscales')->where('id',$id)->update(['topic'=>$request->topic,'brand'=>$request->brand,'model'=>$request->model,'campaign_id'=>$campaigns,'description'=>$request->description]);

        return redirect('/upscale');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
