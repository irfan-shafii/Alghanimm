<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use DB;

class AjaxController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }
    

    public function customerinfo(Request $request){

    if($request->ajax()){

        if(isset($_POST['cusid']) && !empty($_POST['cusid'])) {

        $cusid = $_POST['cusid']; 

        $account = DB::table('account')->where('id_account',$cusid)->get();
        if(count($account)>0){
            $id_account = $account[0]->id_account;
            $fname = $account[0]->first_name;
            $lname = $account[0]->last_name;
            $mobile2 = $account[0]->alternate_mobile;
            $gender = $account[0]->gender;
            $civilid = $account[0]->civil_id;
            $address = $account[0]->address;
        }

        $vehicles = DB::table('vehicles')->where('id_account',$id_account)->get();

        $account_comments = DB::table('opportunity')->where('id_account',$id_account)->orderBy('id_opp','desc')->get();


        $enqHTML = '';


        if(count($account_comments) > 0){
        foreach($account_comments as $comment){

            $enq_cat = DB::table('enquiry_categories')->where('id_enquiry_category',$comment->enquiry_category)->first();
            $enq_sub_cat = DB::table('enquiry_categories')->where('id_enquiry_category',$comment->enquiry_subcategory)->first();
            $enq_category = '';
            $enq_subcategory = '';
            $enq_subcategory2 = '';
            $enq_subcategory3 = '';

             if(!empty($comment->enquiry_subcategory2) || $comment->enquiry_subcategory2 == '0'){

             $enq_sub_cat2 = DB::table('enquiry_categories')->where('id_enquiry_category',$comment->enquiry_subcategory2)->first();

            if(count($enq_sub_cat2) > 0){
              $enq_subcategory2 = "<br>".$enq_sub_cat2->category_name;
            }

            }

            if(!empty($comment->enquiry_subcategory3) || $comment->enquiry_subcategory3 == '0'){

             $enq_sub_cat3 = DB::table('enquiry_categories')->where('id_enquiry_category',$comment->enquiry_subcategory3)->first();

            if(count($enq_sub_cat3) > 0){
              $enq_subcategory3 = "<br>".$enq_sub_cat3->category_name;
            }
             }
            if(count($enq_cat) > 0){
              $enq_category = $enq_cat->category_name;
            }
            if(count($enq_sub_cat) > 0){
              $enq_subcategory = $enq_sub_cat->category_name;
            }

          $enqHTML .='<tr>';
              $enqHTML .='<td>'.$comment->id_opp.'</td>';
              $enqHTML .='<td>'.$comment->id_agent.'</td>';
              $enqHTML .='<td>'.$comment->type_of_profession.'</td>';
              $enqHTML .='<td>'.$comment->date_add.'</td>';
              $enqHTML .='<td>'.$enq_category.'</td>';
              $enqHTML .='<td>'.$enq_subcategory.'</td>';
              $enqHTML .='<td>'.$comment->description.'</td>';
          $enqHTML .='</tr>';


        }
        }



        }
        echo json_encode(array("fname"=>$fname,"lname"=>$lname,"mobile2"=>$mobile2,"gender"=>$gender,"civilid"=>$civilid,"address"=>$address,"vehicles"=>$vehicles,"enqHTML"=>$enqHTML));
    }

    }
    

    public function vehicleinfo(Request $request)
    {
    if($request->ajax())
    {

        if(isset($_POST['vehid']) && !empty($_POST['vehid'])) {

        $vehid = $_POST['vehid']; 

        $vehicle = DB::table('vehicles')->where('id',$vehid)->get();
        if(count($vehicle)>0){
            $vehicleinfo = $vehicle[0]->vehicle_type;
            $vehmodel = $vehicle[0]->vehicle_model;
            $vehyear = $vehicle[0]->vehicle_model_year;
            $vehsalesman = $vehicle[0]->dealer;
            $vehshowroom = $vehicle[0]->town;
            $plateno = $vehicle[0]->vehicle_plate_no;
            $vehcolor = $vehicle[0]->color;
        }
        

        }
        echo json_encode(array("vehicleinfo"=>$vehicleinfo,"vehmodel"=>$vehmodel,"vehyear"=>$vehyear,"vehsalesman"=>$vehsalesman,"vehshowroom"=>$vehshowroom,"plateno"=>$plateno,"vehcolor"=>$vehcolor));
    }

    }





    public function getcategory(Request $request)
    {
    if($request->ajax())
    {
            $nexttype = 0; 
            $divhtml = ''; 
            $subvalue = 0;

        if(isset($_POST['idvalue']) && !empty($_POST['idvalue'])) {

            $categoryid = $_POST['idvalue'];

            $category = DB::table('enquiry_categories')->where('id_enquiry_category',$categoryid)->first();
            $categorytype = $category->category_type;
            $categoryname = $category->category_name;

            if($categorytype =='1'){
            $nexttype = 2 ; 
            $enquiry_categories = DB::table('enquiry_categories')->where('parent_id',$categoryid)->where('category_type',$nexttype)->orderBy('id_enquiry_category','asc')->get();

            }            
            else if($categorytype =='2'){
            $nexttype = 3 ; 
            $enquiry_categories = DB::table('enquiry_categories')->where('parent_id',$categoryid)->where('category_type',$nexttype)->orderBy('id_enquiry_category','asc')->get();

            }           
            else if($categorytype =='3'){
            $nexttype = 4 ; 
            $enquiry_categories = DB::table('enquiry_categories')->where('parent_id',$categoryid)->where('category_type',$nexttype)->orderBy('id_enquiry_category','asc')->get();

            }  
            else if($categorytype =='4'){

            $nexttype = 0 ; 

            $divhtml = ''; 

            if($categoryname =='Yes'){
                $subvalue = 1;
            }

            }


            if($categorytype =='1' || $categorytype =='2' || $categorytype =='3'){
            $divhtml = ''; 
            if(count($enquiry_categories) > 0){
            $divhtml .= '<select class="form-control m-bot15" name="subcategory'.$categorytype.'" id="subcategory'.$nexttype.'" onChange="getcategory(this);" required="">'; 
            $divhtml.='<option value="">Select</option>'; 
            foreach ($enquiry_categories as $enquiries) {
                $divhtml.='<option value="'.$enquiries->id_enquiry_category.'">'.$enquiries->category_name.'</option>'; 
            }
            $divhtml.='</select>';
            }

            }

        }
        echo json_encode(array("divhtml"=>$divhtml,"categorytype"=>$categorytype,"subvalue"=>$subvalue));
    }

    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
