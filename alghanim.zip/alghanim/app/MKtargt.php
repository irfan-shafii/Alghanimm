<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MKtargt extends Model
{
	//protected $connection = 'mysql2';
    protected  $table="mk_00_targt";
}
