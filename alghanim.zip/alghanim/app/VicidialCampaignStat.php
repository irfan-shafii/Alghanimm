<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VicidialCampaignStat extends Model
{
	protected $connection = 'mysql2';
    protected  $table="vicidial_campaign_stats";
}
