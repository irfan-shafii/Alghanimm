<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VicidialHopper extends Model
{
    protected  $table="vicidial_hopper";
}
