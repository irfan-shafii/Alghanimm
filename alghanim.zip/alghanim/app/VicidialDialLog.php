<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VicidialDialLog extends Model
{
	protected $connection = 'mysql2';
    protected  $table="vicidial_dial_log";
}
